import { Composition } from "remotion";
import { AgentSkillTutorial } from "./AgentSkillTutorial";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="AgentSkillTutorial"
        component={AgentSkillTutorial}
        durationInFrames={5400}
        fps={30}
        width={1920}
        height={1080}
      />
    </>
  );
};
